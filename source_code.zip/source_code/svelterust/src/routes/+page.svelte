<script lang="ts">
	import "bootstrap/dist/css/bootstrap.min.css";
	import { invoke } from '@tauri-apps/api/core';
	import { open } from '@tauri-apps/plugin-dialog';
	import { onMount } from 'svelte';

	let folderPath = "";
	let videoFile: File | null = null;
	let videoUrl = "";

	let player = "";
	let indicator = "";
	let pauseTime = 0.0;
	let prevSec = 10;
	let nextSec = 20;

	let message = "";
	let messageType: "success" | "error" | "" = "";
	let messageTimeout: number;

	let showFormPopup = false;
	let pausedTimeFormatted = "00:00:00";
	let videoEl: HTMLVideoElement;

	let isNavbarOpen = false;

	function formatSeconds(seconds: number): string {
		const h = Math.floor(seconds / 3600).toString().padStart(2, '0');
		const m = Math.floor((seconds % 3600) / 60).toString().padStart(2, '0');
		const s = Math.floor(seconds % 60).toString().padStart(2, '0');
		return `${h}:${m}:${s}`;
	}

	async function chooseFolder() {
		const selected = await open({ directory: true });
		if (typeof selected === 'string') {
			folderPath = decodeURIComponent(selected);
			videoFile = null;
			videoUrl = "";
		}
	}

	function onFileSelected(event: Event) {
		const input = event.target as HTMLInputElement;
		if (input.files?.length) {
			videoFile = input.files[0];
			videoUrl = URL.createObjectURL(videoFile);
			updateTitle(videoFile.name);
		}
	}

	function onPause() {
		if (!videoEl) return;
		pauseTime = videoEl.currentTime;
		pausedTimeFormatted = formatSeconds(pauseTime);
		showFormPopup = true;
	}

	async function handleExtract() {
		if (!folderPath || !videoFile) {
			showMessage("Folder and video file are required", "error");
			return;
		}
		const sep = folderPath.endsWith('/') ? '' : '/';
		const fullPath = folderPath + sep + videoFile.name;

		try {
			const result = await invoke("extract_clip", {
				path: fullPath,
				player,
				indicator,
				pauseTime,
				prevSec,
				nextSec
			});
			showMessage(`🎉 Clip saved to: ${result}`, "success");
		} catch (err) {
			console.error(err);
			showMessage(`❌ Error: ${err}`, "error");
		} finally {
			showFormPopup = false;
		}
	}

	function showMessage(msg: string, type: "success" | "error") {
		clearTimeout(messageTimeout);
		message = msg;
		messageType = type;
		messageTimeout = setTimeout(() => {
			message = "";
			messageType = "";
		}, 4000);
	}

	function updateTitle(name: string) {
		const title = document.getElementById("videoTitle");
		if (title) title.textContent = name;
	}

	function toggleNavbar() {
		isNavbarOpen = !isNavbarOpen;
	}
</script>

<!-- UI Layout -->
<div class="container-fluid h-100">
	<div class="row h-100">
		<!-- Horizontal Navbar -->
		<div class="navbar">
			<div class="navbar-content" class:open={isNavbarOpen}>
				<div class="controls">
					<table>
						<tbody>
							<tr>
								<td style="width:50%">
									<button class="btn btn-custom mb-2" on:click={chooseFolder}>Folder</button>
								</td>
								<td style="width:50%">
									<input class="form-control" type="file" on:change={onFileSelected} accept="video/*" />
								</td>
							</tr>
						</tbody>
					</table>
				</div>
				<button class="icon-btn" on:click={toggleNavbar}>
					<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
						<path d="M3 3H21V21H3V3Z" fill="#89CFF0" />
						<path d="M5 5H19V9H5V5Z" fill="#fff" />
					</svg>
					Workspace
				</button>
			</div>
		<hr>
		</div>

		<!-- Main Panel -->
		<div class="col main-display">
			<!-- Toast Message -->
			{#if message}
			<div class={`popup ${messageType}`}>{message}</div>
			{/if}

			<div class="screen">
				{#if videoUrl}
					<video
						bind:this={videoEl}
						src={videoUrl}
						controls
						on:pause={onPause}
						style="max-width: 100%; height: 100%; border-radius: 12px;"
					>
						<track kind="captions" />
						Your browser does not support video.
					</video>
				{:else}
					Preview
				{/if}
			</div>
			<div class="title-container">
				{#if folderPath && videoFile}
				<h4 id="videoTitle" class="text-start">{videoFile.name}</h4>
				<span class="text-muted text-start">{folderPath}</span>
				{:else}
					<h4 id="videoTitle" class="text-start">No File Selected</h4>
					<span class="text-muted text-start">Define your workspace to start</span>
				{/if}
			</div>
		</div>
	</div>
</div>

<!-- Pause Form Overlay -->
{#if showFormPopup}
	<div class="popup-form-overlay">
		<div class="popup-form">
			<button class="close-btn" on:click={() => (showFormPopup = false)}>
				<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
					<path d="M6 6L18 18M18 6L6 18" stroke="#333" stroke-width="2" stroke-linecap="round" />
				</svg>
			</button>
			<h6>Paused at {pausedTimeFormatted} ({pauseTime.toFixed(2)}s)</h6>
			<div class="form-grid">
				<label>
					Player
					<input bind:value={player} placeholder="Enter player name" />
				</label>
				<label>
					Indicator
					<input bind:value={indicator} placeholder="Enter indicator" />
				</label>
				<label>
					Seconds Before
					<input type="number" min="0" bind:value={prevSec} placeholder="10" />
				</label>
				<label>
					Seconds After
					<input type="number" min="0" bind:value={nextSec} placeholder="20" />
				</label>
			</div>
			<div class="form-actions">
				<button class="btn btn-extract" on:click={handleExtract}>Extract Clip</button>
			</div>
		</div>
	</div>
{/if}

<style>
	.navbar {
		position: fixed;
		top: 0;
		right: 0;
		height: 80px;
		background: #fff;
		border-bottom: 1px solid #dee2e6;
		z-index: 1000;
		display: flex;
		justify-content: flex-end;
	}

	.navbar-content {
		display: flex;
		flex-direction: row;
		align-items: center;
		gap: 1rem;
		padding: 1rem;
		transition: all 0.3s ease;
	}

	.navbar-content.open {
		max-width: 400px;
	}

	.navbar-content:not(.open) .controls {
		max-width: 0;
		opacity: 0;
		overflow: hidden;
	}

	.controls {
		display: flex;
		flex-direction: column;
		gap: 0.5rem;
		max-width: 250px;
		opacity: 1;
		transition: max-width 0.3s ease, opacity 0.3s ease;
	}

	.icon-btn {
		background: none;
		border: none;
		cursor: pointer;
		padding: 0.5rem;
	}

	.main-display {
		display: flex;
		flex-direction: column;
		gap: 1rem;
		padding: 2rem;
		flex-grow: 1;
		margin-top: 80px;
	}
	
	.screen {
		background: #212529;
		border-radius: 12px;
		height: 400px;
		color: #fff;
		display: flex;
		align-items: center;
		justify-content: center;
		padding: 1rem;
	}

	.title-container h4,
	.title-container span {
		margin: 0;
	}

	.btn-custom {
		background: #0d6efd;
		color: white;
		border: none;
		border-radius: 8px;
		padding: 0.5rem 1rem;
		width: 100%;
	}

	.popup {
		position: fixed;
		top: 1rem;
		right: 1rem;
		padding: 1rem 1.5rem;
		border-radius: 8px;
		font-weight: bold;
		box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
		z-index: 1000;
		opacity: 0.95;
	}
	.popup.success { background: #38a169; color: white; }
	.popup.error { background: #e53e3e; color: white; }

	.popup-form-overlay {
		position: fixed;
		top: 0;
		left: 0;
		right: 0;
		bottom: 0;
		background: rgba(0, 0, 0, 0.5);
		display: flex;
		align-items: center;
		justify-content: center;
		z-index: 2000;
	}

	.popup-form {
		background: white;
		padding: 1rem;
		border-radius: 8px;
		box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
		width: 100%;
		max-width: 400px;
		min-width: 300px;
		display: flex;
		flex-direction: column;
		gap: 0.5rem;
	}

	.popup-form h6 {
		margin: 0;
		font-size: 1rem;
		font-weight: 600;
		color: #333;
	}

	.form-grid {
		display: grid;
		grid-template-columns: 1fr 1fr;
		gap: 0.75rem;
	}

	.popup-form label {
		font-size: 0.85rem;
		font-weight: 500;
		color: #333;
	}

	.popup-form input {
		width: 100%;
		padding: 0.4rem;
		border: 1px solid #ccc;
		border-radius: 4px;
		font-size: 0.85rem;
		transition: border-color 0.2s;
	}

	.popup-form input:focus {
		outline: none;
		border-color: #0d6efd;
	}

	.form-actions {
		display: flex;
		justify-content: flex-end;
		gap: 0.5rem;
	}

	.btn-extract {
		background-color: #38a169;
		color: white;
		border: none;
		padding: 0.5rem 1rem;
		font-weight: 600;
		border-radius: 4px;
		cursor: pointer;
	}

	.btn-extract:hover {
		background-color: #2f855a;
	}

	.close-btn {
		position: absolute;
		top: 0.5rem;
		right: 0.5rem;
		background: #f1f1f1;
		border: none;
		border-radius: 50%;
		width: 24px;
		height: 24px;
		display: flex;
		align-items: center;
		justify-content: center;
		cursor: pointer;
	}

	.close-btn svg {
		width: 16px;
		height: 16px;
	}
</style>