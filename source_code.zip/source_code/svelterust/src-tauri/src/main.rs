// Prevents additional console window on Windows in release, DO NOT REMOVE!!
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use std::{fs, path::Path, process::Command};
use chrono::Local;

#[tauri::command]
fn greet(name: &str) -> String {
    format!("Hello, {}", name)
}

#[tauri::command]
fn extract_clip(
    path: String,
    player: String,
    indicator: String,
    pause_time: f64,
    prev_sec: u32,
    next_sec: u32,
) -> Result<String, String> {
    // Calculate start and duration
    let start = if pause_time < prev_sec as f64 {
        0.0
    } else {
        pause_time - prev_sec as f64
    };
    let duration = prev_sec + next_sec;

    // Format pause_time to hh_mm_ss
    let total_seconds = pause_time.round() as u64;
    let hours = total_seconds / 3600;
    let minutes = (total_seconds % 3600) / 60;
    let seconds = total_seconds % 60;
    let pause_formatted = format!("{:02}:{:02}:{:02}", hours, minutes, seconds);

    // Build folder and output path
    let today = Local::now().format("%Y-%m-%d").to_string();
    let parent = Path::new(&path)
        .parent()
        .ok_or("Invalid file path")?;
    let output_dir = parent.join(format!("fanamby-{}", today));
    fs::create_dir_all(&output_dir).map_err(|e| e.to_string())?;

    let safe_player = player.replace(" ", "_");
    let safe_indicator = indicator.replace(" ", "_");
    let output_filename = format!("{}_[{}]_{}.mp4", safe_player, safe_indicator, pause_formatted);
    let output_path = output_dir.join(output_filename);

    // FFmpeg
    let status = Command::new("ffmpeg")
        .args([
            "-y",
            "-i", &path,
            "-ss", &format!("{:.2}", start),
            "-t", &duration.to_string(),
            "-c", "copy",
            output_path.to_str().unwrap(),
        ])
        .status()
        .map_err(|e| e.to_string())?;

    if status.success() {
        Ok(output_path.to_str().unwrap().to_string())
    } else {
        Err("FFmpeg failed".to_string())
    }
}

fn main() {
  tauri::Builder::default()
      .plugin(tauri_plugin_dialog::init())
      .invoke_handler(tauri::generate_handler![greet, extract_clip])
      .run(tauri::generate_context!())
      .expect("error while running tauri application");
}